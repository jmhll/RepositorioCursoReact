//import Articulo from "./Componentes/Articulo";
import './App.css';
//T5

//import Teclado from './Componentes/Eventos/Teclado';
//import Raton from './Componentes/Eventos/Raton';
//import Touch from './Componentes/Eventos/Touch';
//import Imagen from './Componentes/Eventos/Imagen';
//import Focus from './Componentes/Eventos/Focus';
//import Clip from './Componentes/Eventos/ClipBoard';
import ComponenteEventos from './Componentes/components/ComponenteEvento';


function App() {
  return <ComponenteEventos/> //tema5 Ejercicio
  //return <Clip/>    //tema5 Evento
  //return <Focus/>   //tema5 EventoFocos
  //return <Image/>  //tema5 EventoImagenes
  //return <Touch/> //tema5 EventoTactil
  //return <Raton/> //tema5 EventoRaton
  //return <Teclado/> //tema5 EventoTeclado
  //return <Articulo /> //tema1
}
  
export default App;
