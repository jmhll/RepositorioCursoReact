function Carga(props) {

    return (
        <ul>
            <li>Carga rápida en estación de repostaje: {props.carga}</li>
        </ul>
    )
}